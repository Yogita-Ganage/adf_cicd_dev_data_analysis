# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df= spark.read.format("parquet").load("abfss://bronze@olympicsdldevdl.dfs.core.windows.net/athletes")

# COMMAND ----------

df.display(5)

# COMMAND ----------

df= df.fillna({'birth_place':"Unknown"},{'birth_country': "Unknown"})

# COMMAND ----------

filter_df = df.filter((col("current")==True) &(col("name").isin("GALSTYAN Salvik","HARUTYUNYAN Arsen","SEHEN Sajjad")))
filter_df.display()


# COMMAND ----------

df_transformation = df.withColumn("height",col('height').cast(FloatType()))\
    .withColumn("weight",col('weight').cast(FloatType()))

df_transformation.display()


# COMMAND ----------

df_sorted = df_transformation.sort("height","weight",Ascending=[0,1]).filter(col("weight")>0)
df_sorted.display()


# COMMAND ----------

df_sorted= df_sorted.withColumn("nationality",regexp_replace('nationality','United States', 'US'))
df_sorted.display()

# COMMAND ----------

df_sorted.columns

# COMMAND ----------

df_final = df_sorted.select('Athelete_id',
 'current',
 'name',
 'name_short',
 'name_tv',
 'gender',
 'function',
 'country_code',
 'country',
 'country_long',
 'nationality',
 'nationality_long',
 'nationality_code',
 'height',
 'weight')

# COMMAND ----------

display(df_final)

# COMMAND ----------

from delta.tables import DeltaTable
df_final.write.format("delta")\
        .mode("append")\
        .option("path","abfss://silver@olympicsdldevdl.dfs.core.windows.net/athletes")\
        .saveAsTable("olympics_cata.silver.athletes")
