# Databricks notebook source
my_array = [
            {
             "sourcecontainer": "bronze",
             "sinkcontainer": "silver",
             "rootfolder": "events"},
            {
             "sourcecontainer": "bronze",
             "sinkcontainer": "silver",
             "rootfolder": "coaches"},
        ]


# COMMAND ----------

dbutils.jobs.taskValues.set(key="my_task",value = my_array)

#remeber my_array should not in ""