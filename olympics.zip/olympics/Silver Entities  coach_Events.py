# Databricks notebook source
# MAGIC %md
# MAGIC # Dynamic DataReading
# MAGIC
# MAGIC ###here we had to write value of parameters so we will use forkkflows to get values dynamically
# MAGIC

# COMMAND ----------

dbutils.widgets.text("sourcecontainer","")
dbutils.widgets.text("sinkcontainer","")
dbutils.widgets.text("rootfolder","")
#define parameters

# COMMAND ----------

#get value of parameters
sourcecontainer = dbutils.widgets.get("sourcecontainer")
sinkcontainer = dbutils.widgets.get("sinkcontainer")
rootfolder = dbutils.widgets.get("rootfolder")

# COMMAND ----------

df = spark.read.format("parquet")\
         .load(f"abfss://{sourcecontainer}@olympicsdldevdl.dfs.core.windows.net/{rootfolder}")



# COMMAND ----------

df.write.format("parquet")\
        .mode("overwrite")\
        .option("path",f"abfss://{sinkcontainer}@olympicsdldevdl.dfs.core.windows.net/{rootfolder}")\
        .saveAsTable(f"olympics_cata.{sinkcontainer}.{rootfolder}")

# COMMAND ----------

#%sql
#DROP TABLE olympics_cata.silver.events