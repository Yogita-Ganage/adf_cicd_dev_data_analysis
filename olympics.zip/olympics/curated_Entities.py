# Databricks notebook source
# MAGIC %md
# MAGIC delta live tables gold layer

# COMMAND ----------

# MAGIC %md
# MAGIC # COACHES DATA PIPELINE

# COMMAND ----------

import dlt

# COMMAND ----------

expec_coaches = {
                    "role1": "code is not null",
                    "role2": "current is True",
                }


# COMMAND ----------

expec_nocs = {
                "role1": "code is not null",
            }

# COMMAND ----------

expec_events = {
                "role1": "event is not null",
            }

# COMMAND ----------

# coaches DLT Pipeline

@dlt.table
def source_coaches():
  df = spark.readStream.table("olympics_cata.silver.coaches")
  return df

# COMMAND ----------

@dlt.view

def view_coaches():
    df=spark.readStream.table("LIVE.source_coaches")
    return df

# COMMAND ----------

#creating final table using previous view
@dlt.table

@dlt.expect_all(expec_coaches)
def table_coaches():
    df=spark.readStream.table("LIVE.view_coaches")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ### nocs dlt pipeline

# COMMAND ----------

@dlt.view
def source_nocs():
  df = spark.readStream.table("olympics_cata.silver.nocs")
  return df

# COMMAND ----------

@dlt.table

@dlt.expect_all_or_drop(expec_nocs)
def nocs():
    df = spark.readStream.table("LIVE.source_nocs")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC event table dlt pipeline

# COMMAND ----------

@dlt.view
def source_events():
  df = spark.readStream.table("olympics_cata.silver.events")
  return df

# COMMAND ----------

@dlt.table

@dlt.expect_all(expec_events)
def events():
    df = spark.readStream.table("LIVE.source_events")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC Athletes table with CDC-in Delta live table 

# COMMAND ----------

@dlt.view

def source_athletes():
  df = spark.readStream.table("olympics_cata.silver.athletes")
  return df

# COMMAND ----------

dlt.create_streaming_table("athletes")

# COMMAND ----------

from pyspark.sql.functions import *


dlt.apply_changes(
    target = "athletes",
    source = "source_athletes",
    keys = ["athelete_id"],
    sequence_by = col("height"),
    stored_as_scd_type=1
)