# Databricks notebook source
# MAGIC %md
# MAGIC #Silver Notebbok

# COMMAND ----------

# MAGIC %md
# MAGIC Read nocs.csv file

# COMMAND ----------

df=spark.read.format("csv")\
  .option("header", "true")\
  .option("inferSchema", "true")\
  .load("abfss://bronze@olympicsdldevdl.dfs.core.windows.net/nocs")

#df.display()

# COMMAND ----------

df = df.drop('country')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df = df.withColumn('tag', split(col('tag'), '-')[0])
#display(df)

# COMMAND ----------

df.write.format("delta")\
        .mode("overwrite")\
        .option("path","abfss://silver@olympicsdldevdl.dfs.core.windows.net/nocs")\
        .saveAsTable("olympics_cata.silver.nocs") 

#saved file in parquet with deltalog

# COMMAND ----------

#to create managed table
df.write.format("delta")\
        .mode("overwrite")\
        .saveAsTable("olympics_cata.silver.nocs_man")